export interface Contact{
    id: string;
    userId: string;
    nombre: string;
    email: string;
    telefono: string;
    direccion: string;
}