export interface Contact {
id: string,
nombre: string,
email: string,
telefono: string,
direccion: string,
}